package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ChangePasswordActivity extends AppCompatActivity {
    DBHelper dbh;
    EditText ied , ped;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        ied=findViewById(R.id.ed);
        ped=findViewById(R.id.ed1);
        dbh=new DBHelper(this);
    }


    public void changePassword (View v){
        String stri =ied.getText().toString();
        String strp=ped.getText().toString();
        UserData ud=new UserData(stri,strp);
        int i=dbh.updatePassword(ud,stri);
        Toast.makeText(this, "Password Changed " +i , Toast.LENGTH_SHORT).show();


    }

}