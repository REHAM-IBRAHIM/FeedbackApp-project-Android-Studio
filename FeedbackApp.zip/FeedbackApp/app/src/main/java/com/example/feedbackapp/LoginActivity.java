package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    DBHelper dbh;
    EditText uid , ped;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);




    }

        public void validate (View v){
            uid=findViewById(R.id.uid);
            ped=findViewById(R.id.pass);
            dbh=new DBHelper(this);

            UserData u=dbh.getData(uid.getText().toString());
            if (u!=null){

       // EditText uid=findViewById(R.id.userId);
         //   EditText pass=findViewById(R.id.pass);
         //   String uidstr=uid.getText().toString();
         //   String passtr=pass.getText().toString();
          // if (uidstr.equals("reham") && passtr.equals("123")){
               Intent in =new Intent();
              in.setClass(this,WelcomeActivity.class);
              in.putExtra("id", uid.getText().toString());

            startActivity(in);
           }
           else{

                Toast.makeText(this, "invalid userId or Password , try again!!" , Toast.LENGTH_LONG).show();
              //  uid.setText(null);
              //  pass.setText(null);
            }


        }



    public void callsign  (View v){
      Intent in = new Intent();
      in.setClass(this,SignUpActivity.class);
       startActivity(in);
    }





      /*  حق فيس بوك    */
    public void fb (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.facebook.com"));
       startActivity(in);
    }


    /*  حق  تويتر  */

    public void tw (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.twitter.com"));
        startActivity(in);
    }





    /*   حق انستغرام    */

    public void inst (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.instagram.com"));
        startActivity(in);
    }


}