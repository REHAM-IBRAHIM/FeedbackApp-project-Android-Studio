package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SurveyGymActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey_gym);
    }

    public void subandext2(View v){
        Intent in= new Intent();
        in.setClass(this,ServiceActivity.class);
        startActivity(in);

    }


    public void save2(View v){
        Intent in= new Intent();
        in.setClass(this,ThankActivity.class);
        startActivity(in);

    }


}