package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {
   // ed > user , ed1 > password
    DBHelper dbh;
    EditText ed;
    SQLiteDatabase db;
    EditText ed1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ed = findViewById(R.id.ed);
        dbh = new DBHelper(this);
        // db = dbh.getWritableDatabase();
        //  db.execSQL("create table if not exists empdetail(name text,password text )");
        ed1 = findViewById(R.id.ed1);


        //   <11/1/2021 > هذي اضافه عشان تطلع عند التسجيل علامه تنبيه عرفتي يكون صغيره عندEditText > user
        ed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                ed.setError("user Id must contain @");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // هذي اضافه عشان تطلع عند التسجيل علامه تنبيه عرفتي يكون صغيره عند EditText > password

        ed1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                ed1.setError("password must be >6");
            }
        });

    }


    public void SaveData1(View v) {
        // save user name and pass

        String str = ed.getText().toString();
        String str1 = ed1.getText().toString();

        UserData ud = new UserData(str, str1);
        dbh.addData(ud);
        // db.execSQL("insert into empdetail values('"+str+"','"+str1+"')");
        Toast.makeText(this, "data saved", Toast.LENGTH_LONG).show();

    }



}