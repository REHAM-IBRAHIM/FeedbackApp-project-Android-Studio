package com.example.feedbackapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper  extends SQLiteOpenHelper {

    static final String DB_NAME="Emp";
    static final int DB_VER=3;
    // table name
    static String TABLE_NAME="userdata";
    //columns name
    static String UID="uid";
    static String PASSWORD="pass";

   // DBHelper(Context ct) {
       // super(ct, "Emp.db", null, 3);


    //}
   DBHelper(Context ct) { super(ct, DB_NAME, null, DB_VER); // create database
   }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //create table //

        String createstr="create table "+TABLE_NAME+"("+ UID +" text not null ," + PASSWORD +" text not null"+")";
        db.execSQL(createstr);
    }

    //user define method to insert data into table
    public void  addData (UserData u ){
        SQLiteDatabase db=getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UID, u.getId());
        values.put(PASSWORD,u.getPassword());

        //inserting row
        db.insert(TABLE_NAME,null,values);
        db.close();
    }

    public  UserData getData( String id ){
        SQLiteDatabase db=getReadableDatabase();

        Cursor cr =db.query(TABLE_NAME,new String[]  { UID , PASSWORD},UID+"=?",
                new String[] {id} , null ,null, null);
        UserData ud=null;
        if (cr.moveToFirst()){

            ud =new UserData(cr.getString(0) , cr.getString(1) );

        }
        return ud;
    }


    //read all data
    //public List< SurveyActivity> getAllData() {
       // List<SurveyActivity> udl = new ArrayList<SurveyActivity>();
       // String q = "select * from " + TABLE_NAME;
        //SQLiteDatabase db = getReadableDatabase();
        //Cursor cr = db.rawQuery(q, null);
       // if (cr.moveToFirst()) {
          //  do {
           //     SurveyActivity u = new SurveyActivity();
           //     u.setId(cr.getString(1));
           //     udl.add(u);
         //   } while (cr.moveToNext());


       // }
      //  return udl;
   // }



  // updating password

    public int updatePassword (UserData u , String id ){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues val = new ContentValues();
        val.put(PASSWORD , u.getPassword());

        //updating row
        return  db.update(TABLE_NAME, val , UID + "=?" , new String[] {id});
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
