package com.example.feedbackapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_welcome);

        Intent in1=getIntent();
        Bundle b=in1.getExtras();
        String str=b.getString("id");
        TextView t=findViewById(R.id.uname);
        t.setText("Welcome"+  " " + str);


        /* just on the word welcome ( t1 )*/

       // TextView t1=findViewById(R.id.textview);
        //registerForContextMenu(t1);

         registerForContextMenu(t);

    }

    /* menu on the word  ( copy and paste ) */

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {


         MenuInflater mif = getMenuInflater();
        // mif.inflate(R.menu.mycontext,menu);
        menu.add(1,41,1,"Google");
        menu.add(1,42,2,"FB");


        super.onCreateContextMenu(menu, v, menuInfo);

    }


    /* menu on the word  ( Toast copy and paste )  */

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.cp:

                Toast.makeText(this,"copy item selected " ,Toast.LENGTH_LONG).show();
                     break;
            case R.id.pas:
                Toast.makeText(this,"paste item selected " ,Toast.LENGTH_LONG).show();
                  break;
            case 41:
                Intent in = new Intent(Intent.ACTION_VIEW);
                in.setData(Uri.parse("https://www.google.com"));
                startActivity(in);
                break;
            case 42 :
                Intent in1 = new Intent(Intent.ACTION_VIEW);
                in1.setData(Uri.parse("https://www.facebook.com"));
                startActivity(in1);
        }


        return super.onContextItemSelected(item);
    }








    /* button  */

    public void clic  (View v){
        Intent in = new Intent();
        in.setClass(this,ServiceActivity.class);
        startActivity(in);
    }





    /* menu */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
      /*  menu.add(1,21,3,"Exit");
        menu.add(1,22,1,"Tools");
        menu.add(3,23,2,"Edit"); */



        /*  menu the color */
       /* SubMenu sb =menu.addSubMenu("change color");
        sb.add(2,31,1,"gray");
        sb.add(2,32,2,"image"); */


        MenuInflater mif=getMenuInflater();
        mif.inflate(R.menu.appmenu,menu);

       /* MenuItem mi=menu.add("Logout");
        mi.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                //Toast.makeText(WelcomeActivity.this , "Logout selected " , Toast.LENGTH_LONG).show();
                Intent in=new Intent();
                in.setClass(WelcomeActivity.this ,MainActivity.class);
                startActivity(in);
                return true;
            }
        }); */


        return super.onCreateOptionsMenu(menu);
    }



    /* 3 type  menu */

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        LinearLayout wll=findViewById(R.id.wl);


        switch (item.getItemId()){
            case 21:
               // this.finishAndRemoveTask();
                Toast.makeText(this , "Exit selected " , Toast.LENGTH_LONG).show();
                  break;
            case 22:
                Toast.makeText(this , "Tools selected " , Toast.LENGTH_LONG).show();
               break;
            case 23:
                Toast.makeText(this , "Edit selected " , Toast.LENGTH_LONG).show();


                break;

            case 31:
                wll.setBackgroundColor(Color.LTGRAY);
                break;
            case 32:
                //wll.setBackgroundColor(Color.GRAY);

               wll.setBackgroundResource(R.drawable.menu);

               break;
            case R.id.lg:
                Intent in =new Intent();
                in.setClass(this,MainActivity.class);
                startActivity(in);

                break;
            case R.id.bc:
                wll.setBackgroundColor(Color.LTGRAY);
                break;
            case R.id.chp:
                Toast.makeText(this,"change password button pressed " ,Toast.LENGTH_LONG).show();
               Intent i = new Intent();
               i.setClass(this, ChangePasswordActivity.class);
               startActivity(i);

        }

        return super.onOptionsItemSelected(item);
    }
}