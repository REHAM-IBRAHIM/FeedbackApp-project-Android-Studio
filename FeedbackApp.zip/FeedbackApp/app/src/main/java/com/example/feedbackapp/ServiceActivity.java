package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ServiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);
    }



    /* room */

    public void butroom(View v){
        Intent in= new Intent();
        in.setClass(this,SurveyActivity.class);
        startActivity(in);

    }



    /* gym */

    public void butgy(View v){
        Intent in= new Intent();
        in.setClass(this,SurveyGymActivity.class);
        startActivity(in);

    }

      /* food */

    public void butfood(View v){
        Intent in= new Intent();
        in.setClass(this,SurveyFoodActivity.class);
        startActivity(in);

    }



}