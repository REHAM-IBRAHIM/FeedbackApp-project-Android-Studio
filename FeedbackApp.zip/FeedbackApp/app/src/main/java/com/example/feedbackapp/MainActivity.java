package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    DBHelper dbh;
    EditText uid , ped;
    //SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        uid=findViewById(R.id.uid);
        ped=findViewById(R.id.pass);
        dbh=new DBHelper(this);

    }
    public void callLogin(View v){
        Intent in= new Intent();
        in.setClass(this,LoginActivity.class);
        startActivity(in);

    }

    public void callDial (View v){
        Intent in =new Intent(Intent.ACTION_DIAL);
        startActivity(in);

    }
}