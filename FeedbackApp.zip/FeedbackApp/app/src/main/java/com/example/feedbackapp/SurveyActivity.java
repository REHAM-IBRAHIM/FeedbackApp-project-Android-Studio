package com.example.feedbackapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SurveyActivity extends AppCompatActivity {
    DBHelper dbh;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);
    }

    public void subandext(View v){
        Intent in= new Intent();
        in.setClass(this,ServiceActivity.class);
        startActivity(in);

    }


    public void save(View v){

        Intent in= new Intent();
        in.setClass(this,ThankActivity.class);
        startActivity(in);

    }


}